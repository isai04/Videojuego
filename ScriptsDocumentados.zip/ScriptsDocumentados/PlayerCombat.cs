using UnityEngine;
using UnityEngine.UI;
/*La clase PlayerCombat es un componente de Unity que gestiona el combate del jugador,
 permitiendo al jugador atacar enemigos dentro de un rango específico al presionar un botón.*/
public class PlayerCombat : MonoBehaviour
{
    public Animator animator; // El Animator del jugador
    public float attackRange = 1f; // Rango de ataque
    public int attackDamage = 10; // Daño del ataque
    public LayerMask enemyLayers; // Capas de los enemigos
    public Button BtnAttack;
    private bool isClicked;

    void Update()
    {
         BtnAttack.onClick.AddListener(Clicked);
        if (isClicked)
        {
            Attack();
        }
        else
        {
            animator.SetBool("Attack", false);
        }

        isClicked = false;
    }

    void Clicked()
    {
        isClicked = true;
    }

    void Attack()
    {
        // Reproducir la animación de ataque
         animator.SetBool("Attack", true);

        // Detectar enemigos en el rango de ataque
        Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(transform.position, attackRange, enemyLayers);

        // Aplicar daño a los enemigos detectados
        foreach (Collider2D enemy in hitEnemies)
        {
            enemy.GetComponent<Enemy>().TakeDamage(attackDamage);
        }
    }

    // Dibujar el rango de ataque en la escena para visualización
    void OnDrawGizmosSelected()
    {
        if (transform == null)
            return;

        Gizmos.DrawWireSphere(transform.position, attackRange);
    }
}

