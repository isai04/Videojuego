using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
/*La clase SelectLevel es un componente de Unity que maneja la selección de niveles en un menú de selección de niveles.
 Permite al jugador seleccionar un nivel y comenzar el juego en el nivel elegido,
 además de mostrar elementos visuales correspondientes a la selección actual.*/
public class SelectLevel : MonoBehaviour
{
    public Button boton1;
    public Button boton2;
    public Button boton3;
    public Button btnPlay;
    public GameObject flecha1;
    public GameObject flecha2;
    public GameObject flecha3;
    public GameObject Cassian1;
    public GameObject Cassian2;
    public GameObject Cassian3;
    private int id;
    // Start is called before the first frame update
    void Start()
    {
        boton1.onClick.AddListener(NivelUno);
        boton2.onClick.AddListener(NivelDos);
        boton3.onClick.AddListener(NivelTres);
        btnPlay.onClick.AddListener(GoToPlay);
        
    }

    void NivelUno(){id = 1;}
    void NivelDos(){id = 2;}
    void NivelTres(){id = 3;}

    void GoToPlay()
    {
        switch(id)
        {
            case 1:
                SceneManager.LoadScene("01");
                break;
            case 2:
                SceneManager.LoadScene("aldea1");
                break;
            case 3:
                SceneManager.LoadScene("castillo1");
                break;
            default:
                SceneManager.LoadScene("01");
                break;
        }
    }

    // Update is called once per frame
    void Update()
    {
        switch (id)
        {
            case 1:
                flecha1.SetActive(true);
                flecha2.SetActive(false);
                flecha3.SetActive(false);
                Cassian1.SetActive(true);
                Cassian2.SetActive(false);
                Cassian3.SetActive(false);
                break;

                case 2:
                flecha1.SetActive(false);
                flecha2.SetActive(true);
                flecha3.SetActive(false);
                Cassian1.SetActive(false);
                Cassian2.SetActive(true);
                Cassian3.SetActive(false);
                break;

                case 3:
                flecha1.SetActive(false);
                flecha2.SetActive(false);
                flecha3.SetActive(true);
                Cassian1.SetActive(false);
                Cassian2.SetActive(false);
                Cassian3.SetActive(true);
                break;

            default:
                flecha1.SetActive(true);
                flecha2.SetActive(false);
                flecha3.SetActive(false);
                Cassian1.SetActive(true);
                Cassian2.SetActive(false);
                Cassian3.SetActive(false);
                break;
        }
        
    }
}
