using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
/*La clase SceneLoadManager es un componente de Unity que maneja la carga de escenas con una transición animada.
 Utiliza un Animator para realizar una animación de transición antes de cargar la siguiente escena.*/
public class SceneLoadManager : MonoBehaviour
{
    [SerializeField] private float transitionTime = 1f;
    public Animator TransitionAnimator;
    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 1;
        TransitionAnimator = GetComponentInChildren<Animator>();
    }


    // Update is called once per frame
    void Update()
    {
        if(NextScenePlayer.IsGrounded)
        {
            LoadNextScene();
        }
    }

    public void LoadNextScene()
    {
        int nextSceneIndex = SceneManager.GetActiveScene().buildIndex + 1;
        Debug.Log("Iniciar la corutina");
        StartCoroutine(SceneLoad(nextSceneIndex));
    }

    public IEnumerator SceneLoad(int sceneIndex)
    {
        TransitionAnimator.SetTrigger("StartTransition");
        yield return new WaitForSeconds(transitionTime);
        SceneManager.LoadScene(sceneIndex);
    }

    
}
