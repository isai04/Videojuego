using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/*La clase Enemy es un componente de Unity que representa a un enemigo en un juego.
 Gestiona la vida del enemigo, su animación de muerte y acciones relacionadas cuando el enemigo es derrotado.*/
public class Enemy : MonoBehaviour
{
    public int maxHealth = 100; // Vida máxima del enemigo
    int currentHealth; // Vida actual del enemigo
    public Animator animator; // El Animator del enemigo
    public GameObject enemigo;
    public GameObject panelActividad;
    public GameObject ScoreLive;

    void Start()
    {
        currentHealth = maxHealth; // Inicializar la vida actual
        panelActividad.SetActive(false);
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage; // Reducir la vida

        if (currentHealth <= 0)
        {
            StartCoroutine(Die());
        }
    }

    public IEnumerator Die()
    {
        yield return new WaitForSeconds(0.70f);
        // Reproducir la animación de muerte
        animator.SetTrigger("Die");

        yield return new WaitForSeconds(0.70f);
        // Desactivar el enemigo (puede ser sustituido por una destrucción del objeto)
        enemigo.SetActive(false);
        panelActividad.SetActive(true);
        ScoreLive.SetActive(false);
        PlayerPrefs.SetFloat("PuntosPlayer", Score.puntos);
        Time.timeScale = 0;
    }
}
