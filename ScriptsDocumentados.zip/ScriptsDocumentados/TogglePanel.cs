
/*  Se evalua una variable Panel de tipo GameObject si está existe en la escena*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class TogglePanel : MonoBehaviour
{
        public GameObject panel;

        public void TogglePanelVisibility()
        {
            if (panel != null)
            {
                panel.SetActive(!panel.activeSelf);
            }
        }
    
}
