using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
/*La clase PlayerLives es un componente de Unity que gestiona las vidas del jugador en un juego.
 Controla la interacción con enemigos y maneja la lógica cuando el jugador pierde vidas.*/
public class PlayerLives : MonoBehaviour
{
    public List<GameObject> lifeObjects; // Lista de objetos que representan las vidas del jugador
    private int lives; // Número actual de vidas

    void Start()
    {
        lives = lifeObjects.Count; // Inicializa el número de vidas según la cantidad de objetos
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        // Comprueba si la colisión es con un enemigo
        if (collision.gameObject.CompareTag("Enemy"))
        {
            LoseLife();
        }
    }

    void LoseLife()
    {
        if (lives > 0)
        {
            lives--; // Decrementa el número de vidas
            lifeObjects[lives].SetActive(false); // Desactiva el objeto correspondiente

            if (lives == 0)
            {
                // Aquí puedes añadir la lógica para cuando el jugador pierda todas las vidas, como reiniciar la escena o mostrar una pantalla de game over.
                ReloadScene();
                Debug.Log("Game Over");
            }
        }
    }

    public void ReloadScene()
    {
        // Obtén el nombre de la escena actual
        string currentSceneName = SceneManager.GetActiveScene().name;
        // Carga la escena actual nuevamente
        SceneManager.LoadScene(currentSceneName);
    }
}
