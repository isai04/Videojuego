using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Text.RegularExpressions;
using System.IO;

public class SaveName : MonoBehaviour
{
    // Método para guardar el nombre
     public InputField nameInputField;
     public Text placeholderAdv;
     public GameObject panel;

    /// <summary>
    /// La función 'SavePlayerName' guarda la entrada del nombre del jugador si coincide con la expresión regular especificada
    //patrón, de lo contrario muestra un mensaje que indica un nombre no válido.
    /// </summary>
    public void SavePlayerName()
    {
        string playerName = nameInputField.text;
        string regex = "^[a-zA-Z0-9]+$";
        if (Regex.IsMatch(playerName, regex))
        {
            PlayerPrefs.SetString("PlayerName", playerName);
            PlayerPrefs.Save();
            Debug.Log("Nombre guardado: " + playerName);
            placeholderAdv.text = "";

            if (panel != null)
            {
                panel.SetActive(false);
            }

        }
        else 
        {
            placeholderAdv.text = "Nombre no valido";
            Debug.Log("No se guardo");
        }
    }
}
