using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class playermovement : MonoBehaviour
{

    float horizontalMove = 0, verticalMove = 0;
    /* La línea 'public float runSpeedHorizontal = 2, runSpeedVertical = 3, runSpeed = 1, jumpForce =
    3;' está declarando variables flotantes públicas para la velocidad de carrera horizontal del jugador, la carrera vertical
    velocidad, velocidad total de carrera y fuerza de salto. */
    public float runSpeedHorizontal = 2, runSpeedVertical = 3, runSpeed = 1, jumpForce = 3;

    Rigidbody2D rgbody2D;
    /* La línea 'joystick joystick público;' está declarando una variable pública llamada 'joystick' de tipo
    'Joystick'. Es probable que esta variable se use para hacer referencia a un control de entrada de joystick que el reproductor
    se puede usar para mover al personaje horizontalmente en el juego. Asignando una referencia a un joystick
    en el Editor de Unity, el jugador puede controlar el movimiento horizontal del jugador
    usando la entrada del joystick. */
    public Joystick joystick;
    public Button saltar;

    public SpriteRenderer spriteRenderer;
    public Animator animator;

    /// <summary>
    /// La función Start de C# inicializa la componente Rigidbody2D adjunta al objeto de juego.
    /// </summary>
    void Start()
    {
        rgbody2D = GetComponent<Rigidbody2D>();
    }

    /// <summary>
    /// La función Update mueve el objeto del juego horizontalmente en función de la entrada del joystick 
    //y la variable verticalMove.
    /// </summary>
    void Update()
    {
        horizontalMove = joystick.Horizontal * runSpeedHorizontal;

        transform.position += new Vector3(horizontalMove, verticalMove, 0) * Time.deltaTime * runSpeed;

        if (horizontalMove > 0)
        {
            spriteRenderer.flipX = false;
            animator.SetBool("Run", true);
        }
        else if (horizontalMove < 0)
        {
            spriteRenderer.flipX = true;
            animator.SetBool("Run", true);
        }
        else
        {
            animator.SetBool("Run", false);
        }

        animator.SetBool("JumpC", IsGrounded.activarAnima);
    }

   /// <summary>
   /// La función "saltar" en C# permite que el personaje del jugador salte solo si está conectado a tierra.
   /// </summary>
    public void jump(){
        if(IsGrounded.isGrounded){
            rgbody2D.velocity = new Vector2(rgbody2D.velocity.x, jumpForce);
        }
    }

}
