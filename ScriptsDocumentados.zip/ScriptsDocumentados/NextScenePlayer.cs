using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/*La clase NextScenePlayer es un componente de Unity que detecta si un objeto con el tag "Next" ha entrado o salido de su área de colisión.
 Esto se utiliza para indicar si el jugador está en una posición donde puede proceder a cargar la siguiente escena.*/
public class NextScenePlayer : MonoBehaviour
{
    public static bool IsGrounded;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.CompareTag("Next"))
        {
            IsGrounded = true;
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if(collision.gameObject.CompareTag("Next"))
        {
            IsGrounded = false;
        }
    }
}
