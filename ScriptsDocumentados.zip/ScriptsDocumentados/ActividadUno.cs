using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/*La clase ActividadUno es un componente de Unity que maneja la lógica de una actividad interactiva en un juego o aplicación educativa.
 Gestiona la interfaz de usuario, el puntaje del jugador, y la transición entre diferentes paneles de la actividad.*/
public class ActividadUno : MonoBehaviour
{
    public Text ScoreFinal;
    public Text PuntajeAct;
    public Text PuntajeFinalText;
    public Text RetroalimentacionText;
    public Button[] buttonsToCheck;
    public GameObject[] paneles;
    private int indicePaneles;
    private int indiceRespuestas;
    private float puntaje;
    private float puntajeFinal = 0;
    private float playerScore;
    public InputField[] Inputs;
    public string[] respuestas;
    public bool Interruptor;

    
    void Start()
    {
        LoadScore();

        foreach (Button button in buttonsToCheck)
        {
            if (button != null)
            {
                button.onClick.AddListener(() => OnButtonClick(button));
            }
        }

        indicePaneles = 0;
        indiceRespuestas = 0;
        puntaje = 0;

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //Recupera el Score
    void LoadScore()
    {
        if (PlayerPrefs.HasKey("PuntosPlayer"))
        {
            playerScore = PlayerPrefs.GetFloat("PuntosPlayer");
            ScoreFinal.text = playerScore.ToString("0");
            Debug.Log("Puntuación cargada: " + playerScore);
        }
        else
        {
            Debug.Log("No se encontró una puntuación guardada.");
        }
    }

    void OnButtonClick(Button button)
    {
        if(Interruptor)
        {
            if(Inputs[indiceRespuestas].text ==  respuestas[indiceRespuestas] && Inputs[indiceRespuestas+1].text ==  respuestas[indiceRespuestas+1])
            {
                puntaje += 10;
            }
            indiceRespuestas += 2;
        } 
        else
        {
            // Verificar si el botón tiene el tag "True"
            if (button.CompareTag("Correcto"))
            {
                Debug.Log("El botón " + button.name + " tiene el tag 'Correcto'.");
                // Aquí puedes agregar las acciones que desees realizar si la condición se cumple
                puntaje = puntaje + 10;
                Debug.Log(puntaje);
        }
        }

        indicePaneles += 1;
        ActivarPanel(indicePaneles);

    }

    void ActivarPanel(int indicePaneles)
    {
        if(indicePaneles == 3)
        {
            paneles[indicePaneles].SetActive(true);
            PuntajeAct.text = puntaje.ToString("0");
            puntajeFinal = puntaje + playerScore;
            PuntajeFinalText.text = puntajeFinal.ToString("0");   
            paneles[indicePaneles-1].SetActive(false);

            if(puntaje < 20)
            {
                RetroalimentacionText.text = "Obtuviste una calificación muy baja, tienes que estudiar más sobre el going to.";
            }
            else
            {
                RetroalimentacionText.text = "Bien Hecho, haz obtenido un score satisfacotrio en las actividades";
            }

        }
        else
        {
            for(int i = 0; i <= paneles.Length; i++)
            {
                if(i == indicePaneles)
                {
                    paneles[i].SetActive(true);
                }
                else
                {
                    paneles[i].SetActive(false);
                }
            }
        }
    }
}
