using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Score : MonoBehaviour
{
    public float segundos;
    public static float puntos;
    public Text texto;
    public List<string> escenasConTemporizador; // Lista de escenas donde el temporizador está activo

    // Start is called before the first frame update
    void Start()
    {
        // Comprueba si la escena actual está en la lista de escenas con temporizador
        if (escenasConTemporizador.Contains(SceneManager.GetActiveScene().name))
        {
            puntos = segundos; // Inicializa el temporizador
        }
        else
        {
            puntos = Mathf.Infinity; // Desactiva el temporizador
        }
    }

    // Update is called once per frame
    void Update()
    {
        // Solo decrementar el temporizador si está activo
        if (puntos != Mathf.Infinity)
        {
            puntos -= Time.deltaTime;
            texto.text = puntos.ToString("0");

            if (puntos <= 0)
            {
                ReloadScene();
            }
        }
    }

    public void ReloadScene()
    {
        // Obtén el nombre de la escena actual
        string currentSceneName = SceneManager.GetActiveScene().name;
        // Carga la escena actual nuevamente
        SceneManager.LoadScene(currentSceneName);
    }
}
