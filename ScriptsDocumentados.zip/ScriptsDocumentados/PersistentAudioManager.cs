using UnityEngine;
/*La clase PersistentAudioManager es un componente de Unity que gestiona la reproducción de música de fondo y asegura que el audio persista entre cambios de escena.
 También proporciona métodos para pausar y reanudar la música.*/
public class PersistentAudioManager : MonoBehaviour
{
    [SerializeField] private AudioClip backgroundMusic; // El clip de audio a reproducir
    private AudioSource audioSource;

    private static PersistentAudioManager instance = null;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject); // Hace que este GameObject persista entre escenas
        }
        else
        {
            Destroy(gameObject); // Destruye este GameObject si ya existe una instancia
            return;
        }

        // Obtén el componente AudioSource
        audioSource = GetComponent<AudioSource>();

        // Configura el AudioSource
        audioSource.clip = backgroundMusic;
        audioSource.loop = true; // Configura el audio para que se reproduzca en bucle
        audioSource.Play(); // Reproduce el audio
    }

    public void PauseMusic()
    {
        if (audioSource.isPlaying)
        {
            audioSource.Pause();
        }
    }

    public void ResumeMusic()
    {
        if (!audioSource.isPlaying)
        {
            audioSource.Play();
        }
    }
}
