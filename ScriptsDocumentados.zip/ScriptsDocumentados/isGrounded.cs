using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* La clase IsGrounded de C# se usa para determinar si un objeto está actualmente conectado a tierra en función de
colisiones de gatillo. */
public class IsGrounded : MonoBehaviour
{
    public static bool isGrounded;
    public static bool activarAnima;

    private void OnTriggerEnter2D(Collider2D collision){
         if(collision.gameObject.CompareTag("Terrain"))
        {
            isGrounded = true;
            Debug.Log("Tocando el terreno");
            activarAnima = false;
        }
    }
    
    private void OnTriggerExit2D(Collider2D collision){
         if(collision.gameObject.CompareTag("Terrain"))
        {
        isGrounded = false;
        Debug.Log("En el aire");
        activarAnima = true;
        }
        
    }
}
