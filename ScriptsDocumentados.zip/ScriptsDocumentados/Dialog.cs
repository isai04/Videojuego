using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
/*La clase Dialog es un componente de Unity que gestiona el diálogo entre un personaje y el jugador en un juego. Controla la visualización de líneas de diálogo en un panel, 
mostrando texto letra por letra para simular la escritura y permitiendo al jugador avanzar a la siguiente línea de diálogo con un botón.*/
public class Dialog : MonoBehaviour
{
    private bool IsPlayerInRange;
    private bool didDialogueStar;
    private int LineIndex;
    private bool buttonClick;
    public Button btnNext;
    private float typingTime = 0.05f;
    [SerializeField] private GameObject dialogueMark;
    [SerializeField, TextArea(4, 6)] private string[] dialogueLines;
    public GameObject dialoguePanel;
    public Text dialogueText;
    public GameObject ScoreAndLive;
    
    void Start()
    {
        btnNext.onClick.AddListener(ButtonClicked);
    }

    void ButtonClicked()
    {
        buttonClick = true;
    }
    void Update()
    {
        if(IsPlayerInRange && buttonClick)
        {
            buttonClick = false;
            if(!didDialogueStar)
            {
                StarDialogue();
                ScoreAndLive.SetActive(false);
            }
            else if(dialogueText.text == dialogueLines[LineIndex])
            {
                NextDialogueLine();
            }
            else
            {
                StopAllCoroutines();
                dialogueText.text = dialogueLines[LineIndex];
            }
        }
    }

    private void StarDialogue()
    {
        didDialogueStar = true;
        dialoguePanel.SetActive(true);
        dialogueMark.SetActive(false);
        LineIndex = 0;
        Time.timeScale = 0f;
        StartCoroutine(ShowLine());
    }

    private void NextDialogueLine()
    {
        LineIndex++;
        if(LineIndex < dialogueLines.Length)
        {
            StartCoroutine(ShowLine());
        }
        else
        {
            didDialogueStar = false;
            dialoguePanel.SetActive(false);
            dialogueMark.SetActive(true);
            Time.timeScale = 1f;
            ScoreAndLive.SetActive(true);
        }
    }

    private IEnumerator ShowLine()
    {
        dialogueText.text = string.Empty;

        foreach(char ch in dialogueLines[LineIndex])
        {
            dialogueText.text += ch;
            yield return new WaitForSecondsRealtime(typingTime);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.CompareTag("Player"))
        {
            IsPlayerInRange = true;
            dialogueMark.SetActive(true);
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if(collision.gameObject.CompareTag("Player"))
        {
            IsPlayerInRange = false;
            dialogueMark.SetActive(false);
        }
    }
}
