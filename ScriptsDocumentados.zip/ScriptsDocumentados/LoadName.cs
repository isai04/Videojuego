using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LoadName : MonoBehaviour
{
  public Text nameText;

    void Start()
    {
       /* Este fragmento de código comprueba si existe un nombre de jugador en PlayerPrefs. Si el nombre de un jugador
       existe (determinado por la clave "PlayerName" en PlayerPrefs), carga el nombre del jugador usando
       el método 'LoadPlayerName()', luego establece el texto de un elemento de la interfaz de usuario para mostrar un mensaje 
       de bienvenida que incluya el nombre del jugador. Además, registra un mensaje que dice que el nombre existe. */
       
        if (PlayerPrefs.HasKey("PlayerName"))
        {
            string playerName = LoadPlayerName();
            nameText.text = "Bienvenido " + playerName + " a esta gran aventura";
            Debug.Log("Nombre existe");
        }
        else
        {
            nameText.text = "Bienvenido usuario a esta aventura, completa todos los niveles";
            Debug.Log("No existe nombre");
        }
    }

    /*   <summary>
         La función 'LoadPlayerName' recupera el nombre del jugador de las preferencias del jugador y lo registra en
         la consola.
         </summary>
         <returns>
         El método 'LoadPlayerName' devuelve el nombre del reproductor que se carga desde PlayerPrefs. Si no hay
         player name se encuentra en PlayerPrefs, devuelve el nombre predeterminado "DefaultName".
        </returns>*/
    public string LoadPlayerName()
    {
        string playerName = PlayerPrefs.GetString("PlayerName", "DefaultName");
        Debug.Log("Nombre cargado: " + playerName);
        return playerName;
    }
}
