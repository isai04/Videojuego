using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

/* La clase GoToScena de C# contiene un método que cambia la escena mediante SceneManager.LoadScene. */
public class GoToScena : MonoBehaviour
{
    public void CambiarEscena(string escena)
    {
        SceneManager.LoadScene(escena);
    }

}
