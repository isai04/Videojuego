using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
/*La clase CaidaVacio es un componente de Unity que detecta cuando el jugador cae en un área vacía 
(representado por el tag "Player"). Cuando esto ocurre, la escena se reinicia automáticamente.*/
public class CaidaVacio : MonoBehaviour
{
    private bool isVacio;
    void Update()
    {
        if(isVacio)
        {
            ReloadScene();
        }
    }

    void OnTriggerEnter2D(Collider2D collision){
         if(collision.gameObject.CompareTag("Player"))
        {
            isVacio = true;
        }
    }

    public void ReloadScene()
    {
        // Obtén el nombre de la escena actual
        string currentSceneName = SceneManager.GetActiveScene().name;
        // Carga la escena actual nuevamente
        SceneManager.LoadScene(currentSceneName);
    }
}
